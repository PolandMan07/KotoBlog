let kotolubność = prompt('Czy lubisz koty? (Odpowiedz "Tak" lub "Nie")')
var miau = new Audio("mew.wav");
